export default {
    mongodbMemoryServerOptions: {
        binary: {
            version: '6.0.6',
            skipMD5: true
        },
        instance: {
            port: 27017
        },
        autoStart: false
    }
};