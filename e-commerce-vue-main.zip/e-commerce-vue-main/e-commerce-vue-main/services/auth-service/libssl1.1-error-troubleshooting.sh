#!/bin/bash

wget http://security.debian.org/debian-security/pool/updates/main/o/openssl/libssl1.1_1.1.1w-0+deb11u2_amd64.deb
sudo dpkg -i libssl1.1_1.1.1w-0+deb11u2_amd64.deb
